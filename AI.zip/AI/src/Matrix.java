
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Collections;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Map;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.HashMap;


public class Matrix extends SearchProblem {
	
	//carry is the amount of hostages Neo is allowed to carry
	static int carry =0 ;
	//Neo's x position
	static int neuX = 0 ;
	//Neo's y position
	static int neuY = 0 ;
	//The total number of hostages
	static int noHostages = 0 ;
	
	//Initializes the Matrix class
	Matrix(State initialState){
		this.initialState = new State(initialState.x , initialState.y);
	}
	
	//Returns a copy of the 2d array
	static String[][] copyArray(String[][] grid){
		String [][] copiedGrid = new String[grid.length][grid[0].length];
		
		for(int i = 0; i<grid.length ; i++) {
			for(int j =0 ; j<grid[0].length ; j++) {
				copiedGrid[i][j] = grid[i][j];
			}
		}
		return copiedGrid;
	}
	//Prints all the values in a 2d array of strings
	static void arrayPrinter(String [][] arr) {
		for(String [] rows : arr) {
			for(String val : rows) {
				if(val == null)
					System.out.print("[null      ]");
				else if(val.length() ==5)
					System.out.print("["+val + "     ]");
				else if(val.length() ==3)
					System.out.print("["+val + "       ]");
				else if(val.length() ==4)
					System.out.print("["+val + "      ]");
				else if(val.length() ==9)
					System.out.print("["+val + " ]");
				else
					System.out.print("["+val + "]");
					
			}
			System.out.println();
		}
	}
	
	//Checks if there are agents around the location
	static boolean isThereAgents(int x, int y , String[][] grid) {
		if(x <grid.length-1 && grid[x+1][y].contains("Agent"))
			return true;
		if(x >0 && grid[x-1][y].contains("Agent"))
			return true;
		if(y <grid[0].length-1 && grid[x][y+1].contains("Agent"))
			return true;
		if(y >0 && grid[x][y-1].contains("Agent"))
			return true;
		
		return false;
	}

	//Calculates the number of Hostages in a grid, it is used to help calculate our path cost function
	static int noOfHostages(String [][] grid) {
		int ans = 0;
		for(int i = 0; i <grid.length ;i++) {
			for(int j = 0 ; j<grid[0].length;j++) {
				if(grid[i][j].contains("Hostage") && !grid[i][j].contains("100"));
					ans++;
			}
		}
		return ans;
	}
	
	//Generates a random grid in the string form
	static String genGrid() {
		
		//These strings will hold the locations of their corresponding names
		StringBuilder constants = new StringBuilder(); //holds m,n,NeoX,NeoY,C,TelephoneX,Telephoney
		StringBuilder agents = new StringBuilder();
		StringBuilder pills = new StringBuilder();
		StringBuilder pads = new StringBuilder();
		StringBuilder hostages = new StringBuilder();
		ArrayList<String> padList = new ArrayList<>();
		
		//initialize the random values of the hostages and the pills 
		noHostages = 3 + (int) (Math.random() * 8);
		int noPills = (int) (Math.random()*(noHostages+1));
		int placedPills = 0;
		
		//Keeps track of the number of pads placed in the grid
		int noPads = 0;
		
		
		
		//initialize grid parameters and the maximum number of hostages Neo can carry
		int m = 5 + (int) (Math.random() * 11);
		int n = 5 + (int) (Math.random() * 11);
		int c = (int) (Math.random()* 5);
		
		//Makes sure the is no overlapping
		boolean [][] occupied = new boolean [m][n];
		
		//Calculates Neo's initial position
		int neoX = (int) (Math.random() * m);
		int neoY = (int) (Math.random() * n);
		occupied[neoX][neoY] = true;
		
		//appends Neo's position to the stringbuilder
		constants.append(m + "," + n + "; " + c + "; " + neoX + "," + neoY + "; ");
		
		//Calculates the random position of the telephone booth and appends the value to the stringbuilder
		while(true) {
			int telephoneX = (int) (Math.random() * m);
			int telephoneY = (int) (Math.random() * n);
			
			if(!occupied[telephoneX][telephoneY]) {
				occupied[telephoneX][telephoneY] = true;
				constants.append(telephoneX + "," + telephoneY + "; ");
				break;
			}
		}
		
		//initialize hostages
		for(int i = 0 ; i < noHostages ; i++) {
			while(true) {
				int hostageX = (int) (Math.random() * m);
				int hostageY = (int) (Math.random() * n);
				int damage = 1 + (int) (Math.random() * 99);
				
				if(!occupied[hostageX][hostageY]) {
					occupied[hostageX][hostageY] = true;
					hostages.append(hostageX + "," + hostageY + "," + damage + ",");
					break;
				}
			}
		}
		
		
		//filling the grid
		
		for(int i = 0 ; i <m ; i++) {
			for(int j = 0 ; j<n ; j++) {
				if(occupied[i][j]) continue;
				
				//This a random value the determine the object in the cell
				int ObjDict = (int) (Math.random()*15);
				if(noPills == placedPills) ObjDict = (int)(Math.random()*14);
				
				switch(ObjDict) {
				case 3:agents.append(i + "," + j + ",");break;
				case 4:padList.add(i + "," + j + ",");noPads++;break;
				case 5:agents.append(i + "," + j + ",");break;
				case 6:padList.add(i + "," + j + ",");noPads++;break;
				case 14:pills.append(i + "," + j + ",");placedPills++;break;
				}
				
			}
		}
		
		
		//removing the commas in the strings and inserting the semicolons
		
		hostages.deleteCharAt(hostages.length()-1);
		hostages.append(";");
		
		
		if(agents.length() != 0) {
			agents.deleteCharAt(agents.length()-1);
		}
		agents.append("; ");
		
		
		if(pills.length() != 0) {
			pills.deleteCharAt(pills.length()-1);
		}
		pills.append("; ");
		
		//shuffles the pads so that they are not sequentially paired
		Collections.shuffle(padList);
		
		//if the number of pads is odd, simply remove the last pad
		if(noPads%2 ==1) {
			padList.remove(padList.size()-1);
		}
		
		if(padList.size() != 0) {
			StringBuilder tmp = new StringBuilder(padList.get(padList.size()-1));
			tmp.deleteCharAt(tmp.length()-1);
			padList.remove(padList.size()-1);
			padList.add(tmp.toString());
		}
		
		
		for(String s : padList) pads.append(s);
		
		
		pads.append("; ");
		
		//finalizing the String
		StringBuilder finalstring = new StringBuilder(constants);
		finalstring.append(agents);
		finalstring.append(pills);
		finalstring.append(pads);
		finalstring.append(hostages);
		
		System.out.println(finalstring);
		
		return finalstring.toString();
	}
	//Transforms the grid String to a 2d array of strings
	public static String [][] visualize(String grid ) {
		
		//Create all variables, Neo's x position, y position and maximum carry amount are global
		//X denotes the x position of the object and y denotes the y position
		int width = 0;
		int height = 0;
		int telephoneX = 0;
		int telephoneY = 0;
		ArrayList<Integer> agentX = new ArrayList<>();
		ArrayList<Integer> agentY = new ArrayList<>();
		ArrayList<Integer> pillX = new ArrayList<>();
		ArrayList<Integer> pillY = new ArrayList<>();
		ArrayList<Integer> startPadX = new ArrayList<>();
		ArrayList<Integer> startPadY = new ArrayList<>();
		ArrayList<Integer> endPadX = new ArrayList<>();
		ArrayList<Integer> endPadY = new ArrayList<>();
		ArrayList<Integer> hostageX = new ArrayList<>();
		ArrayList<Integer> hostageY = new ArrayList<>();
		ArrayList<Integer> hostageDamage = new ArrayList<>();
		
		//used to concatinate each position's values
		int conc = 0;
		
		//used to choose the correct variable to store into
		int Case1 = 0;
		int Case2 = 0;
		
		
		//fill all variables
		for(int i = 0 ; i < grid.length() ; i++) {
			if(grid.charAt(i) == ' ')continue;
			
			if(grid.charAt(i) == ',') {
				
				switch(Case1) {
				case(0):
					width = conc;
					break;
				case(2):
					neuX = conc;
					break;
				case(3):
					telephoneX = conc;
					break;
				case(4):
					if(Case2 == 0) agentX.add(conc);
					if(Case2 == 1) agentY.add(conc);
					break;
				case(5):
					if(Case2 == 0) pillX.add(conc);
					if(Case2 == 1) pillY.add(conc);
					break;
				case(6):
					if(Case2 == 0) startPadX.add(conc);
					if(Case2 == 1) startPadY.add(conc);
					if(Case2 == 2) endPadX.add(conc);
					if(Case2 == 3) endPadY.add(conc);
					break;
				case(7):
					if(Case2 == 0) hostageX.add(conc);
					if(Case2 == 1) hostageY.add(conc);
					if(Case2 == 2) hostageDamage.add(conc);
					break;
				}
				
				
				if(Case1 == 7 && Case2 == 2 || Case1 == 6 && Case2 == 3 || Case1 < 6 && Case2 == 1) {
					Case2 = 0;
				}
				else {
					Case2++;
				}
				 conc = 0;
				continue;
			}
			
			
			if(grid.charAt(i) == ';') {
				switch(Case1) {
				case(0):
					height = conc;
					break;
				case(1):
					carry = conc;
					break;	
				case(2):
					neuY = conc;
					break;
				case(3):
					telephoneY = conc;
					break;
				case(4):
					agentY.add(conc);
					break;
				case(5):
					pillY.add(conc);
					break;
				case(6):
					endPadY.add(conc);
					break;
				case(7):
					hostageDamage.add(conc);
					break;
				}
				conc = 0;
				Case2 = 0;
				Case1++;
				continue;
			}
			
			conc *= 10;
			conc += grid.charAt(i) - 48;
			
			
		}
		
		
		//create grid
		String[][] myGrid = new String[width][height];
		
		//fill the grid with "null" strings
		for(int i =0 ; i <myGrid.length;i++)for(int j =0 ; j<myGrid[0].length ;j++)myGrid[i][j] = "null";
		
		//fill in the grid
		myGrid[neuX][neuY] = "Neo";
		
		//If overlapping occurs print "Error"
		if(myGrid[telephoneX][telephoneY] != "null") System.out.println("ERROR");
			
		myGrid[telephoneX][telephoneY] = "Telephone";
		
		for(int i = 0 ; i <agentX.size() ; i++) {
			if(myGrid[agentX.get(i)][agentY.get(i)] != "null") System.out.println("ERROR");
			myGrid[agentX.get(i)][agentY.get(i)] = "Agent";
		}
		
		for(int i = 0 ; i <pillX.size() ; i++) {
			if(myGrid[pillX.get(i)][pillY.get(i)] != "null") System.out.println("ERROR");
			myGrid[pillX.get(i)][pillY.get(i)] = "Pill";
		}
		
		for(int i = 0 ; i <startPadX.size() ; i++) {
			if(myGrid[startPadX.get(i)][startPadY.get(i)] != "null" || myGrid[endPadX.get(i)][endPadY.get(i)] != "null") System.out.println("ERROR");
			
			myGrid[startPadX.get(i)][startPadY.get(i)] = "Pad" + i;
			myGrid[endPadX.get(i)][endPadY.get(i)] = "Pad" + i;
		}
		
		for(int i = 0 ; i <hostageX.size() ; i++) {
			if(myGrid[hostageX.get(i)][hostageY.get(i)] != "null") System.out.println("ERROR");
			if(hostageDamage.get(i) <10) myGrid[hostageX.get(i)][hostageY.get(i)] = "Hostage,0" + hostageDamage.get(i);
			else myGrid[hostageX.get(i)][hostageY.get(i)] = "Hostage," + hostageDamage.get(i);
			
		}
		
		
		return myGrid;
		
	}
	//Updates the grid and state according to the action
	static void updateGrid(String[][]grid , Node node) {
		//The new position values that will be calculated
		int newX = node.state.x;
		int newY = node.state.y;
		
		//Number of special agents in the grid
		int noSpecialAgents = 0;
		
		
		//checks if the operator was takePill
		boolean tookPill = false;
		
		//First we remove Neo from the grid and put him back after performing the action
		if(grid[newX][newY].equals("Neo"))grid[newX][newY] = "null";
		else {
			grid[newX][newY] = grid[newX][newY].substring(4);
		}
		
		//Calculates and applies the changes in the grid from Neo's action
		switch(node.operator){
		case("up"):
			newX++;
			break;
		case("down"):
			newX--;
			break;
		case("left"):
			newY--;
			break;
		case("right"):
			newY++;
			break;
		case("carry"):
			//Changes the hostage to CarriedHostage
			grid[newX][newY] ="Carried" +grid[newX][newY];
			node.state.carried++;
			node.state.stats[2]++;
			break;
		case("drop"):
			node.state.carried = 0;
			node.state.stats[2] =0;
			node.state.pillsTaken++;
			node.state.stats[7]++;
			//In the implementation the carried hostages remain in place, so we check their locations and set it to null
			for(int i = 0 ; i<grid.length ;i++) {
				for(int j = 0 ; j<grid[0].length;j++) {
					if(!grid[i][j].contains("CarriedHostage")) continue;
					
					//Checks if the hostage is dead or alive
					if(!grid[i][j].contains("100")) {
						node.state.savedHost++;
						node.state.stats[5]++;	
					}
					else {
						node.state.killedHost++;
						node.state.stats[4]++;	
					}
					grid[i][j] = "null";
					
				}
			}		
			break;
		case("takePill"):
			//removes the pill from the gird
			grid[newX][newY] = "null";
			//implies that in this Node Neo has taken a pill
			tookPill=true;
			node.state.pillsTaken++;
			node.state.stats[7]++;
			node.state.health = Math.min(5, node.state.health+1);
			node.state.stats[3]= node.state.health;
			break;
		case("kill"):
			node.state.health--;
			node.state.stats[3]--;
			//checks for agents and hostages that have turned into agents around Neo and sets them to null
			//Special agent is a hostage that have turned into an agent
			if(newX>0 && grid[newX-1][newY].contains("Agent")) {
				if(grid[newX-1][newY].contains("SpecialAgent")) {
					node.state.stats[4]++;
					node.state.killedHost++;
				}
				node.state.killedAgents++;
				node.state.stats[6]++;
				grid[newX-1][newY] = "null";
			}
			if(newX<grid.length-1 && grid[newX+1][newY].contains("Agent")) {
				if(grid[newX+1][newY].contains("SpecialAgent")) {
					node.state.stats[4]++;
					node.state.killedHost++;
				}
				node.state.stats[6]++;
				node.state.killedAgents++;
				grid[newX+1][newY] = "null";
			}
			if(newY>0 && grid[newX][newY-1].contains("Agent")) {
				if(grid[newX][newY-1].contains("SpecialAgent")) {
					node.state.stats[4]++;
					node.state.killedHost++;
				}
				node.state.stats[6]++;
				node.state.killedAgents++;
				grid[newX][newY-1] = "null";
			}
			if(newY<grid[0].length-1  && grid[newX][newY+1].contains("Agent")) {
				if(grid[newX][newY+1].contains("SpecialAgent")) {
					node.state.stats[4]++;
					node.state.killedHost++;
				}
				node.state.stats[6]++;
				node.state.killedAgents++;
				grid[newX][newY+1] = "null";
			}
			break;
		case("fly"):
			//done is used to break out of the loop after finding the other pad
			boolean done = false;
			for(int i = 0 ; i<grid.length ;i++) {
				for(int j = 0 ; j<grid[0].length;j++) {
					if(grid[i][j].equals(grid[newX][newY]) && (i!=newX || j!=newY)) {
						newX = i;newY =j;
						done = true;
						break;
					}
				}
				if(done)break;
			}	
			break;
		}
		
		
		
		//The decrease in the hostage's health after this action
		//The damage varialbe is responsible for taking the previous damage
		//These are all technical things to unify the String's format
		for(int i = 0; i <grid.length;i++) {
			for(int j = 0 ;j<grid[0].length;j++) {
				if(grid[i][j] == "null")continue;
				int damage = 0;
				if(grid[i][j].contains("CarriedHostage")) {
					damage = Integer.parseInt(grid[i][j].substring(15));
					if(damage == 100) continue;
					if(tookPill) damage = Math.max(0, damage-20);
					else damage = Math.min(100, damage+2);
					grid[i][j] = "CarriedHostage,";
					if(damage <10) {
						grid[i][j] += "0";
					}
					grid[i][j] += damage;
				}
				else if(grid[i][j].contains("Hostage")) {
					damage = Integer.parseInt(grid[i][j].substring(8));
					if(tookPill) damage = Math.max(0, damage-20);
					else damage = Math.min(100, damage+2);
					if(damage == 100) {
						grid[i][j] = "SpecialAgent";
						continue;
					}
					grid[i][j] = "Hostage,";
					if(damage < 10) {
						grid[i][j] += "0";
					}
					grid[i][j] += damage;
				}
			}
		}
		
		for(String [] width : grid) {
			for(String entities : width) {
				if(entities.contains("SpecialAgent"))
					noSpecialAgents++;
			}
		}
		
		if(grid[newX][newY] == "null")grid[newX][newY] = "Neo";
		else grid[newX][newY] = "Neo," + grid[newX][newY];
		
		node.state.x = newX;
		node.state.stats[0] = newX;
		node.state.y = newY;
		node.state.stats[1] = newY;
		node.state.specialAgents = noSpecialAgents;
		node.state.stats[8] = noSpecialAgents;
		
	}
	
	
	static String solve(String grid , String strategy , boolean visualize) {
		
		String [][] myGrid = visualize(grid);
		if(visualize) {
			arrayPrinter(myGrid);
			System.out.println();
			System.out.println();
		}
		
		
		String ans = "The input method is invalid";
		
		switch(strategy) {
		case("BF"): ans = breadthFirstSearch(myGrid);break;
		case("DF"): ans = depthFirstSearch(myGrid);break;
		case("ID"): ans = iterativeDeepeningSearch(myGrid);break;
		case("UC"): ans = uniformCostSearch(myGrid);break;
		case("GR1"): ans = greedySearch1(myGrid);break;
		case("GR2"): ans = greedySearch2(myGrid);break;
		case("AS1"): ans = AStar1(myGrid);break;
		case("AS2"): ans = AStar2(myGrid);break;
		
		}
		
		if(ans.equals("")) {
			return "There is no solution to this grid";
		}
		return ans;
		
	}
	
	//Returns weather or not Neo can do each operation
	public static boolean isTheMoveValid(Node node , String[][] grid , String action) {
		int x = node.state.x;
		int y = node.state.y;
		int carried = node.state.carried;
		int health = node.state.health;
		
		//checks if the destined position has an agent
		boolean noAgentThere = false;
		//checks if at the time Neo reaches the destination a Hostage will turn into an agent
		boolean noAlmostDeadHostage = false;
		//checks weather Neo can carry another hostage or not
		boolean canCarry = false;
		//checks if there is a hostage in the cell
		boolean isThereHostage = false;
		//checks if Neu is carring a hostage
		boolean isCarring = false;
		//checks if the current location has a telephone
		boolean telephoneExist = false;
		//checks if there is a pill in the location
		boolean pillExist = false;
		//checks if Neo's health is sufficient for a kill action
		boolean sufficientHealth = false;
		//checks if there are agents around Neo
		boolean isThereAgentsAround = false;
		//checks if there is a pad in Neo's location
		boolean padExist = false;
		
		switch(action) {
		case("up"):
			if(x >= grid.length-1)
				return false;
			noAgentThere = !grid[x+1][y].contains("Agent");
			noAlmostDeadHostage = !grid[x+1][y].equals("Hostage,99") && !grid[x+1][y].equals("Hostage,98");
			return ( noAgentThere && noAlmostDeadHostage);
		case("down"):
			if(x <= 0)
				return false;
			noAgentThere = !grid[x-1][y].contains("Agent");
			noAlmostDeadHostage = !grid[x-1][y].equals("Hostage,99")  && !grid[x-1][y].equals("Hostage,98");
			return (noAgentThere && noAlmostDeadHostage);
		case("right"):
			if(y >= grid[0].length-1)
				return false;
			noAgentThere = !grid[x][y+1].contains("Agent");
			noAlmostDeadHostage = !grid[x][y+1].equals("Hostage,99") && !grid[x][y+1].equals("Hostage,98");
			return (noAgentThere && noAlmostDeadHostage);
		case("left"):
			if(y <= 0)
				return false;
			noAgentThere = !grid[x][y-1].contains("Agent");
			noAlmostDeadHostage = !grid[x][y-1].equals("Hostage,99") && !grid[x][y-1].equals("Hostage,98");
			return (noAgentThere && noAlmostDeadHostage);
		case("carry"):
			canCarry = carried<carry;
			isThereHostage = grid[x][y].contains("Hostage") && !grid[x][y].contains("Carried");
			return (canCarry && isThereHostage);
		case("drop"):
			isCarring = carried>0;
			telephoneExist = grid[x][y].contains("Telephone");
			return (isCarring && telephoneExist);
		case("takePill"):
			pillExist = grid[x][y].contains("Pill");
			return (pillExist);
		case("kill"):
			sufficientHealth = health>1;
			isThereAgentsAround = isThereAgents(x,y,grid);
			 return(sufficientHealth && isThereAgentsAround);
		case("fly"):
			padExist = grid[x][y].contains("Pad");
			return (padExist);	
		}
		
		System.out.println("Error");
		return false;
	}
	
	//fills in the data types needed to calculate the first heuristic function
	public static int fillHostages(String [][] grid ,ArrayList<truple> hostages , ArrayList<Integer> carriedhostages , pair telephoneLocation) {
		//hostages is a list containing their position in the grid and their health;
		//carriedhostages is a list containing their health, because their location is Neo's location;
		//telephonec contains the telephone location
		//this method reuturns the number of pills in the grid
		
		
		
		int pills = 0;
		
		for(int i = 0; i<grid.length ;i++) {
			for(int j =0 ;j<grid[0].length;j++) {
				String object = grid[i][j];
				
				if(object.equals("Neo"))continue;
				
				if(object.contains("Neo"))object = object.substring(4);
				
				if(object.contains("Telephone")){
					telephoneLocation.x = i;telephoneLocation.y =j;
					}
				else if(object.contains("Hostage")) {
					int damage = Integer.parseInt(object.substring(object.length()-2 , object.length()));
					if(object.contains("Carried")) {
						carriedhostages.add(damage);
					}
					else {
						hostages.add(new truple(i,j,damage));
					}
				}
				else if(object.contains("Pill")) {
					pills++;
				}
			}
		}
		return pills;
	}
	//This method returns all the shorcuts using the pads and their cost. Needed to calculate the heuristic
	public static HashMap<ShortCut , Integer> fillPads(String[][] grid) {
		
		HashMap<String , pair> padLocation = new HashMap<>();
		HashMap<String , pair> padDestination = new HashMap<>();
		
		
		for(int i = 0 ;i <grid.length ; i++) {
			for(int j = 0 ; j<grid[0].length ; j++) {
				String object = grid[i][j];
				
				if(object.equals("Neo"))continue;
				if(object.contains("Neo"))object = object.substring(4);
				
				if(object.contains("Pad")){
					if(padLocation.containsKey(object)) {
						padDestination.put(object, new pair(i,j));
					}
					else {
						padLocation.put(object, new pair(i,j));
					}
				}
				
			}
		}
		HashMap<ShortCut,Integer> ans = new HashMap<>();
		
		findAllGridPermutations(ans ,padLocation , padDestination , new HashSet<String>() ,new ShortCut(0,0,0,0) ,0);
		
		return ans;
	}
	
	public static void findAllGridPermutations(HashMap<ShortCut,Integer> ans ,HashMap<String , pair> padLocation , HashMap<String , pair> padDestination , HashSet<String> coveredPad ,ShortCut shortCut , int cost){
		
		
		for(Map.Entry pad : padLocation.entrySet()) {
			if(!coveredPad.add((String) pad.getKey())) {
				continue;
			}
			pair thisPadLocation =(pair) pad.getValue();
			pair thisPadDestination = padDestination.get(pad.getKey());
			
			if(cost == 0) {
				shortCut = new ShortCut(thisPadLocation.x , thisPadLocation.y , thisPadDestination.x , thisPadDestination.y);
				ans.put(shortCut, 1);
				findAllGridPermutations(ans , padLocation , padDestination , coveredPad , new ShortCut(shortCut.start.x , thisPadLocation.y , thisPadDestination.x , thisPadDestination.y), 1);
				
				shortCut = new ShortCut(thisPadDestination.x , thisPadDestination.y, thisPadLocation.x , thisPadLocation.y);
				ans.put(shortCut, 1);
				findAllGridPermutations(ans , padLocation , padDestination , coveredPad , new ShortCut(thisPadDestination.x , thisPadDestination.y ,thisPadLocation.x , thisPadLocation.y), 1);
			}
			else {
				
			}
			coveredPad.remove((String) pad.getKey());
		}
		
		
	}
	
	
	public static String breadthFirstSearch(String[][] grid) {
		
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//The queue of objects stores each Nodes and they're grid 
		Queue<Object> BF = new LinkedList<>();
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue
		BF.add(grid);
		BF.add(firstNode);
		
		//breadth first operation
		while(!BF.isEmpty()) {
			
			 String [][] nodeGrid = (String [][]) BF.remove();
			 Node node = (Node) BF.remove();
			 if(!repeatedStates.add(node.state)) {
				continue;
			}
				
			nodesExpanded++;
			
			//checks if this node is the goal node
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 	
			}
				
				
			//insert the children of the node
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				updateGrid(upGrid, upNode);
					
				BF.add(upGrid);
				BF.add(upNode);
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				updateGrid(downGrid, downNode);
					
				BF.add(downGrid);
				BF.add(downNode);
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				updateGrid(rightGrid, rightNode);
					
				BF.add(rightGrid);
				BF.add(rightNode);
			}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
				updateGrid(leftGrid, leftNode);
					
				BF.add(leftGrid);
				BF.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
				updateGrid(carryGrid, carryNode);
					
				BF.add(carryGrid);
				BF.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);
				updateGrid(dropGrid, dropNode);
					
				BF.add(dropGrid);
				BF.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				updateGrid(pillGrid, pillNode);
					
				BF.add(pillGrid);
				BF.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				updateGrid(killGrid, killNode);
					
				BF.add(killGrid);
				BF.add(killNode);
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
				updateGrid(flyGrid, flyNode);
					
				BF.add(flyGrid);
				BF.add(flyNode);
			}
		}
		return "";
	}
	public static String depthFirstSearch(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//The stack of objects stores each Nodes and they're grid 
		Stack<Object> DF = new Stack<>();
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the stack
		DF.push(firstNode);
		DF.push(grid);
		
		
		
		while(!DF.isEmpty()) {
			 String [][] nodeGrid = (String [][]) DF.pop();
			 Node node = (Node) DF.pop();
			 
			if(!repeatedStates.add(node.state)) {
				continue;
			}
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
				
			//insert the children of this node
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				updateGrid(upGrid, upNode);
				
				DF.add(upNode);
				DF.add(upGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				updateGrid(downGrid, downNode);
				
				DF.add(downNode);
				DF.add(downGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				updateGrid(rightGrid, rightNode);
				
				DF.add(rightNode);
				DF.add(rightGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
				updateGrid(leftGrid, leftNode);
				
				DF.add(leftNode);
				DF.add(leftGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
				updateGrid(carryGrid, carryNode);
				
				DF.add(carryNode);
				DF.add(carryGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);
				updateGrid(dropGrid, dropNode);
				
				DF.add(dropNode);
				DF.add(dropGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				updateGrid(pillGrid, pillNode);
				
				DF.add(pillNode);
				DF.add(pillGrid);
				
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				updateGrid(killGrid, killNode);
				
				DF.add(killNode);
				DF.add(killGrid);
				
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
				updateGrid(flyGrid, flyNode);
				
				DF.add(flyNode);
				DF.add(flyGrid);
				
			}
		}
		
		return "";
	}
	public static String iterativeDeepeningSearch(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		
		Stack<Object> ID = new Stack<>();
		
		//Initialize the state, matrix and node
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//The maximum depth will be 1000
		int depth= 0;
		
		while(depth<1000) {
			//pushes the first node and grid after each incrementation of the depth
			ID.push(firstNode);
			ID.push(grid);
			//resets the hashset after each incrementation of the depth
			HashSet<State> repeatedStates = new HashSet<>();
			
			while(!ID.isEmpty()) {
				 String [][] nodeGrid = (String [][]) ID.pop();
				 Node node = (Node) ID.pop();
				 
				 //if the state was already handled, continue
				 if(!repeatedStates.add(node.state)) {
					 continue;	
				 }
				 
				nodesExpanded++;
				
				if(matrix.goalTest(node, noHostages , nodeGrid)) {
					arrayPrinter(nodeGrid);
					return goalString(node , nodesExpanded);
				}
				
				//if the depth of this node is equal to the maximum depth of this iteration, don't insert its children
				if(node.depth ==depth) {
					continue;
				}
				
				//insert the node's children
				if(isTheMoveValid(node , nodeGrid , "up")) {
					String[][] upGrid = copyArray(nodeGrid);
					Node upNode = matrix.up(node);
					updateGrid(upGrid, upNode);
					
					ID.add(upNode);
					ID.add(upGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "down")) {
					String[][] downGrid = copyArray(nodeGrid);
					Node downNode = matrix.down(node);
					updateGrid(downGrid, downNode);
					
					ID.add(downNode);
					ID.add(downGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "right")) {
					String[][] rightGrid = copyArray(nodeGrid);
					Node rightNode = matrix.right(node);
					updateGrid(rightGrid, rightNode);
					
					ID.add(rightNode);
					ID.add(rightGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "left")) {
					String[][] leftGrid = copyArray(nodeGrid);
					Node leftNode = matrix.left(node);
					updateGrid(leftGrid, leftNode);
					
					ID.add(leftNode);
					ID.add(leftGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "carry")) {
					String[][] carryGrid = copyArray(nodeGrid);
					Node carryNode = matrix.carry(node);
					updateGrid(carryGrid, carryNode);
					
					ID.add(carryNode);
					ID.add(carryGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "drop")) {
					String[][] dropGrid = copyArray(nodeGrid);
					Node dropNode = matrix.drop(node);
					updateGrid(dropGrid, dropNode);
					
					ID.add(dropNode);
					ID.add(dropGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "takePill")) {
					String[][] pillGrid = copyArray(nodeGrid);
					Node pillNode = matrix.takePill(node);
					updateGrid(pillGrid, pillNode);
					
					ID.add(pillNode);
					ID.add(pillGrid);
					
				}
					
				if(isTheMoveValid(node , nodeGrid , "kill")) {
					String[][] killGrid = copyArray(nodeGrid);
					Node killNode = matrix.kill(node);
					updateGrid(killGrid, killNode);
					
					ID.add(killNode);
					ID.add(killGrid);
					
				}
				if(isTheMoveValid(node , nodeGrid , "fly")) {
					String[][] flyGrid = copyArray(nodeGrid);
					Node flyNode = matrix.fly(node);
					updateGrid(flyGrid, flyNode);
					
					ID.add(flyNode);
					ID.add(flyGrid);
					
				}
				
			}
			depth++;
		}
		
		return "";
	}
	public static String uniformCostSearch(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//Initializes a hashmap to store and find the grid of each node
		HashMap<Node , String[][]> findGrid = new HashMap<>();
		//Initializes a priorityQueue to store the nodes according to their path cost value
		PriorityQueue<Node> UC =new PriorityQueue<>((x, y) -> x.pathCost-y.pathCost);
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue and hashmap
		UC.add(firstNode);
		findGrid.put(firstNode, grid);
		
		
		while(!UC.isEmpty()) {
			 Node node =  UC.remove();
			 String [][] nodeGrid = findGrid.remove(node);
			 
			 if(!repeatedStates.add(node.state)) {
				 continue;
			 }
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
			
			//calculates the number of hostages alive, because it helps in calculating the path cost value
			int hostages = 0;
			
			//insert the node's children
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				
				hostages = noOfHostages(upGrid);
				matrix.assignPathCost(upNode, hostages);
				
				updateGrid(upGrid, upNode);
					
					
				findGrid.put(upNode, upGrid);	
				UC.add(upNode);			
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				
				hostages = noOfHostages(downGrid);
				matrix.assignPathCost(downNode, hostages);
				
				updateGrid(downGrid, downNode);
				
				findGrid.put(downNode, downGrid);	
				UC.add(downNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				
				hostages = noOfHostages(rightGrid);
				matrix.assignPathCost(rightNode, hostages);	
				
				updateGrid(rightGrid, rightNode);
					
				findGrid.put(rightNode, rightGrid);	
				UC.add(rightNode);
				}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
				
				hostages = noOfHostages(leftGrid);
				matrix.assignPathCost(leftNode, hostages);
						
				updateGrid(leftGrid, leftNode);
						
				findGrid.put(leftNode, leftGrid);	
				UC.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
				
				hostages = noOfHostages(carryGrid);
				matrix.assignPathCost(carryNode, hostages);
						
				updateGrid(carryGrid, carryNode);
					
				findGrid.put(carryNode, carryGrid);	
				UC.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);
				
				hostages = noOfHostages(dropGrid);
				matrix.assignPathCost(dropNode, hostages);	
				
				updateGrid(dropGrid, dropNode);
					
				findGrid.put(dropNode, dropGrid);	
				UC.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				
				hostages = noOfHostages(pillGrid);
				matrix.assignPathCost(pillNode, hostages);
				
				updateGrid(pillGrid, pillNode);	
					
				findGrid.put(pillNode, pillGrid);	
				UC.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				
				hostages = noOfHostages(killGrid);
				//The number of special agents that will die by this move, affects the path cost
				matrix.assignPathCost(killNode, hostages);
				
				updateGrid(killGrid, killNode);
					
				findGrid.put(killNode, killGrid);	
				UC.add(killNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
				
				hostages = noOfHostages(flyGrid);
				matrix.assignPathCost(flyNode, hostages);
						
				updateGrid(flyGrid, flyNode);
			
				findGrid.put(flyNode, flyGrid);	
				UC.add(flyNode);	
			}
		}
		return "";
	}
	public static String greedySearch1(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//Initializes a hashmap to store and find the grid of each node
		HashMap<Node , String[][]> findGrid = new HashMap<>();
		//Initializes a priorityQueue to store the nodes according to their path cost value
		PriorityQueue<Node> UC =new PriorityQueue<>((x, y) -> x.heuristicValue-y.heuristicValue);
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue and hashmap
		UC.add(firstNode);
		findGrid.put(firstNode, grid);
		
		
		while(!UC.isEmpty()) {
			 Node node =  UC.remove();
			 String [][] nodeGrid = findGrid.remove(node);
			 
			 if(!repeatedStates.add(node.state)) {
				 continue;
			 }
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
			
			//insert the node's children
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				
				updateGrid(upGrid, upNode);
				
				matrix.assignHeuristic(upNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(upNode, upGrid);	
				UC.add(upNode);			
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				
				updateGrid(downGrid, downNode);
				
				matrix.assignHeuristic(downNode, null, null, null, null, null, nodesExpanded);
				
				findGrid.put(downNode, downGrid);	
				UC.add(downNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				
				updateGrid(rightGrid, rightNode);
				
				matrix.assignHeuristic(rightNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(rightNode, rightGrid);	
				UC.add(rightNode);
				}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
						
				updateGrid(leftGrid, leftNode);
				
				matrix.assignHeuristic(leftNode, null, null, null, null, null, nodesExpanded);
						
				findGrid.put(leftNode, leftGrid);	
				UC.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
						
				updateGrid(carryGrid, carryNode);
				
				matrix.assignHeuristic(carryNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(carryNode, carryGrid);	
				UC.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);	
				
				updateGrid(dropGrid, dropNode);
				
				matrix.assignHeuristic(dropNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(dropNode, dropGrid);	
				UC.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				
				updateGrid(pillGrid, pillNode);	
				
				matrix.assignHeuristic(pillNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(pillNode, pillGrid);	
				UC.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				
				updateGrid(killGrid, killNode);
				
				matrix.assignHeuristic(killNode, null, null, null, null, null, nodesExpanded);
					
				findGrid.put(killNode, killGrid);	
				UC.add(killNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
						
				updateGrid(flyGrid, flyNode);
				
				matrix.assignHeuristic(flyNode, null, null, null, null, null, nodesExpanded);
			
				findGrid.put(flyNode, flyGrid);	
				UC.add(flyNode);	
			}
		}
		return "";
	}
	public static String greedySearch2(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//Initializes a hashmap to store and find the grid of each node
		HashMap<Node , String[][]> findGrid = new HashMap<>();
		//Initializes a priorityQueue to store the nodes according to their path cost value
		PriorityQueue<Node> UC =new PriorityQueue<>((x, y) -> x.heuristicValue-y.heuristicValue);
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue and hashmap
		UC.add(firstNode);
		findGrid.put(firstNode, grid);
		
		
		while(!UC.isEmpty()) {
			 Node node =  UC.remove();
			 String [][] nodeGrid = findGrid.remove(node);
			 
			 if(!repeatedStates.add(node.state)) {
				 continue;
			 }
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
			
			//insert the node's children
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				
				updateGrid(upGrid, upNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(upNode, upGrid);	
				UC.add(upNode);			
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				
				updateGrid(downGrid, downNode);
				
				matrix.assignHeuristic2();
				
				findGrid.put(downNode, downGrid);	
				UC.add(downNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				
				updateGrid(rightGrid, rightNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(rightNode, rightGrid);	
				UC.add(rightNode);
				}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
						
				updateGrid(leftGrid, leftNode);
				
				matrix.assignHeuristic2();
						
				findGrid.put(leftNode, leftGrid);	
				UC.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
						
				updateGrid(carryGrid, carryNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(carryNode, carryGrid);	
				UC.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);	
				
				updateGrid(dropGrid, dropNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(dropNode, dropGrid);	
				UC.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				
				updateGrid(pillGrid, pillNode);	
				
				matrix.assignHeuristic2();
					
				findGrid.put(pillNode, pillGrid);	
				UC.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				
				updateGrid(killGrid, killNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(killNode, killGrid);	
				UC.add(killNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
						
				updateGrid(flyGrid, flyNode);
				
				matrix.assignHeuristic2();
			
				findGrid.put(flyNode, flyGrid);	
				UC.add(flyNode);	
			}
		}
		return "";
	}
	public static String AStar1(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//Initializes a hashmap to store and find the grid of each node
		HashMap<Node , String[][]> findGrid = new HashMap<>();
		//Initializes a priorityQueue to store the nodes according to their path cost value
		PriorityQueue<Node> UC =new PriorityQueue<>((x, y) -> (x.pathCost + x.heuristicValue) - (y.pathCost+y.heuristicValue));
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue and hashmap
		UC.add(firstNode);
		findGrid.put(firstNode, grid);
		
		
		while(!UC.isEmpty()) {
			 Node node =  UC.remove();
			 String [][] nodeGrid = findGrid.remove(node);
			 
			 if(!repeatedStates.add(node.state)) {
				 continue;
			 }
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
			
			//calculates the number of hostages alive, because it helps in calculating the path cost value
			int hostages = 0;
			
			//insert the node's children
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				
				hostages = noOfHostages(upGrid);
				matrix.assignPathCost(upNode, hostages);
				
				updateGrid(upGrid, upNode);
				
				matrix.assignHeuristic(upNode, null, null, null, null, null, hostages);
					
					
				findGrid.put(upNode, upGrid);	
				UC.add(upNode);			
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				
				hostages = noOfHostages(downGrid);
				matrix.assignPathCost(downNode, hostages);
				
				updateGrid(downGrid, downNode);
				
				matrix.assignHeuristic(downNode, null, null, null, null, null, hostages);
				
				findGrid.put(downNode, downGrid);	
				UC.add(downNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				
				hostages = noOfHostages(rightGrid);
				matrix.assignPathCost(rightNode, hostages);	
				
				updateGrid(rightGrid, rightNode);
				
				matrix.assignHeuristic(rightNode, null, null, null, null, null, hostages);
					
				findGrid.put(rightNode, rightGrid);	
				UC.add(rightNode);
				}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
				
				hostages = noOfHostages(leftGrid);
				matrix.assignPathCost(leftNode, hostages);
						
				updateGrid(leftGrid, leftNode);
				
				matrix.assignHeuristic(leftNode, null, null, null, null, null, hostages);
						
				findGrid.put(leftNode, leftGrid);	
				UC.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
				
				hostages = noOfHostages(carryGrid);
				matrix.assignPathCost(carryNode, hostages);
						
				updateGrid(carryGrid, carryNode);
				
				matrix.assignHeuristic(carryNode, null, null, null, null, null, hostages);
					
				findGrid.put(carryNode, carryGrid);	
				UC.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);
				
				hostages = noOfHostages(dropGrid);
				matrix.assignPathCost(dropNode, hostages);	
				
				updateGrid(dropGrid, dropNode);
				
				matrix.assignHeuristic(dropNode, null, null, null, null, null, hostages);
					
				findGrid.put(dropNode, dropGrid);	
				UC.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				
				hostages = noOfHostages(pillGrid);
				matrix.assignPathCost(pillNode, hostages);
				
				updateGrid(pillGrid, pillNode);	
				
				matrix.assignHeuristic(pillNode, null, null, null, null, null, hostages);
					
				findGrid.put(pillNode, pillGrid);	
				UC.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				
				hostages = noOfHostages(killGrid);
				//The number of special agents that will die by this move, affects the path cost
				matrix.assignPathCost(killNode, hostages);
				
				updateGrid(killGrid, killNode);
				
				matrix.assignHeuristic(killNode, null, null, null, null, null, hostages);
					
				findGrid.put(killNode, killGrid);	
				UC.add(killNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
				
				hostages = noOfHostages(flyGrid);
				matrix.assignPathCost(flyNode, hostages);
						
				updateGrid(flyGrid, flyNode);
				
				matrix.assignHeuristic(flyNode, null, null, null, null, null, hostages);
			
				findGrid.put(flyNode, flyGrid);	
				UC.add(flyNode);	
			}
		}
		return "";
	}
	public static String AStar2(String[][] grid) {
		//Calculates the expanded nodes
		int nodesExpanded = 0;
		
		//Initializes a hashset to check if a sate has already been covered
		HashSet<State> repeatedStates = new HashSet<>();
		//Initializes a hashmap to store and find the grid of each node
		HashMap<Node , String[][]> findGrid = new HashMap<>();
		//Initializes a priorityQueue to store the nodes according to their path cost value
		PriorityQueue<Node> UC =new PriorityQueue<>((x, y) -> (x.pathCost + x.heuristicValue) - (y.pathCost+y.heuristicValue));
		
		//Initialize the state, matrix and node 
		State initialState = new State(neuX,neuY);
		Matrix matrix = new Matrix(initialState);
		Node firstNode = new Node(initialState);
		
		//insert the first node and grid in the queue and hashmap
		UC.add(firstNode);
		findGrid.put(firstNode, grid);
		
		
		while(!UC.isEmpty()) {
			 Node node =  UC.remove();
			 String [][] nodeGrid = findGrid.remove(node);
			 
			 if(!repeatedStates.add(node.state)) {
				 continue;
			 }
				
			nodesExpanded++;
			
			if(matrix.goalTest(node, noHostages , nodeGrid)) {
				arrayPrinter(nodeGrid);
				return goalString(node , nodesExpanded); 
			}
			
			//calculates the number of hostages alive, because it helps in calculating the path cost value
			int hostages = 0;
			
			//insert the node's children
			if(isTheMoveValid(node , nodeGrid , "up")) {
				String[][] upGrid = copyArray(nodeGrid);
				Node upNode = matrix.up(node);
				
				hostages = noOfHostages(upGrid);
				matrix.assignPathCost(upNode, hostages);
				
				updateGrid(upGrid, upNode);
				
				matrix.assignHeuristic2();
					
					
				findGrid.put(upNode, upGrid);	
				UC.add(upNode);			
			}
			if(isTheMoveValid(node , nodeGrid , "down")) {
				String[][] downGrid = copyArray(nodeGrid);
				Node downNode = matrix.down(node);
				
				hostages = noOfHostages(downGrid);
				matrix.assignPathCost(downNode, hostages);
				
				updateGrid(downGrid, downNode);
				
				matrix.assignHeuristic2();
				
				findGrid.put(downNode, downGrid);	
				UC.add(downNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "right")) {
				String[][] rightGrid = copyArray(nodeGrid);
				Node rightNode = matrix.right(node);
				
				hostages = noOfHostages(rightGrid);
				matrix.assignPathCost(rightNode, hostages);	
				
				updateGrid(rightGrid, rightNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(rightNode, rightGrid);	
				UC.add(rightNode);
				}
			if(isTheMoveValid(node , nodeGrid , "left")) {
				String[][] leftGrid = copyArray(nodeGrid);
				Node leftNode = matrix.left(node);
				
				hostages = noOfHostages(leftGrid);
				matrix.assignPathCost(leftNode, hostages);
						
				updateGrid(leftGrid, leftNode);
				
				matrix.assignHeuristic2();
						
				findGrid.put(leftNode, leftGrid);	
				UC.add(leftNode);
			}
			if(isTheMoveValid(node , nodeGrid , "carry")) {
				String[][] carryGrid = copyArray(nodeGrid);
				Node carryNode = matrix.carry(node);
				
				hostages = noOfHostages(carryGrid);
				matrix.assignPathCost(carryNode, hostages);
						
				updateGrid(carryGrid, carryNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(carryNode, carryGrid);	
				UC.add(carryNode);
			}
			if(isTheMoveValid(node , nodeGrid , "drop")) {
				String[][] dropGrid = copyArray(nodeGrid);
				Node dropNode = matrix.drop(node);
				
				hostages = noOfHostages(dropGrid);
				matrix.assignPathCost(dropNode, hostages);	
				
				updateGrid(dropGrid, dropNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(dropNode, dropGrid);	
				UC.add(dropNode);
			}
			if(isTheMoveValid(node , nodeGrid , "takePill")) {
				String[][] pillGrid = copyArray(nodeGrid);
				Node pillNode = matrix.takePill(node);
				
				hostages = noOfHostages(pillGrid);
				matrix.assignPathCost(pillNode, hostages);
				
				updateGrid(pillGrid, pillNode);	
				
				matrix.assignHeuristic2();
					
				findGrid.put(pillNode, pillGrid);	
				UC.add(pillNode);
			}
				
			if(isTheMoveValid(node , nodeGrid , "kill")) {
				String[][] killGrid = copyArray(nodeGrid);
				Node killNode = matrix.kill(node);
				
				hostages = noOfHostages(killGrid);
				//The number of special agents that will die by this move, affects the path cost
				matrix.assignPathCost(killNode, hostages);
				
				updateGrid(killGrid, killNode);
				
				matrix.assignHeuristic2();
					
				findGrid.put(killNode, killGrid);	
				UC.add(killNode);	
			}
			if(isTheMoveValid(node , nodeGrid , "fly")) {
				String[][] flyGrid = copyArray(nodeGrid);
				Node flyNode = matrix.fly(node);
				
				hostages = noOfHostages(flyGrid);
				matrix.assignPathCost(flyNode, hostages);
						
				updateGrid(flyGrid, flyNode);
				
				matrix.assignHeuristic2();
			
				findGrid.put(flyNode, flyGrid);	
				UC.add(flyNode);	
			}
		}
		return "";
	}
	
	
	
	
	
	public static String goalString (Node node , int nodesExpanded) {
		if(node.parent == null) return "";
		String ans = "";
		int HostagesKilled = node.state.killedHost;
		int AgentsKilled= node.state.killedAgents;
		
		while(node.operator != null) {
			ans = node.operator + "," + ans;
			node = node.parent;
		}
		
		ans = ans.substring(0, ans.length()-1);
		ans += ";" + HostagesKilled + ";" + AgentsKilled + ";" + nodesExpanded + ";";
		
		return ans;
	}
	
	
	
	public static void test(String randomGrid , String ans) {
		String [][] grid = visualize(randomGrid);
		
		Node node = new Node(new State(neuX ,neuY));
		Matrix matrix = new Matrix(new State(neuX ,neuY));
		
		arrayPrinter(grid);
		System.out.println();
		System.out.println();
		
		String action = "";
		
		for(char c : ans.toCharArray()) {
			if(c == ',' || c== ';') {
				switch(action) {
				case("up"): node = matrix.up(node) ;updateGrid(grid, node);break;
				case("down"): node = matrix.down(node) ;updateGrid(grid, node);break;
				case("left"): node = matrix.left(node) ;updateGrid(grid, node);break;
				case("right"): node = matrix.right(node) ;updateGrid(grid, node);break;
				case("carry"): node = matrix.carry(node) ;updateGrid(grid, node);break;
				case("drop"): node = matrix.drop(node) ;updateGrid(grid, node);break;
				case("takePill"): node = matrix.takePill(node) ;updateGrid(grid, node);break;
				case("kill"): node = matrix.kill(node) ;updateGrid(grid, node);break;
				case("fly"): node = matrix.fly(node) ;updateGrid(grid, node);break;
				}
				System.out.println();
				System.out.println();
				System.out.println(node.operator);
				arrayPrinter(grid);
				action = "";
			}
			else action += c;
		}
	}
	
	
	
	public static void main(String[]args) {
		//System.out.println(solve(genGrid() , "UC" , true));
		HashSet<String> h = new HashSet<>();
		String s = "kk";
		h.add(s);
		System.out.println(h.add(s));
		h.remove(s);
		System.out.println(h.add(s));
		
		
//		System.out.println();
//		System.out.println();
//		noHostages = 9;
//		String grid = "5,10; 4; 0,0; 4,6; 1,4,1,7; 1,0,4,1; 0,6,4,0,3,2,4,2,4,4,4,7; 3,8,19,1,1,91,2,7,38,0,1,14,4,9,39,0,5,8,0,4,43,0,7,38,1,5,37;";
//		String ans ="right,carry,right,up,up,down,kill,down,right,right,carry,right,right,up,up,up,up,drop,down,down,down,left,carry,down,carry,right,right,carry,right,up,up,up,carry,left,kill,left,up,drop,right,right,kill,left,left;5;3;121626;"  ;
//		test(grid , ans);
		
	}
	
}