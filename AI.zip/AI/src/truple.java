
public class truple {
	int x;
	int y;
	int z;
	public truple(int i , int j , int k) {
		this.x = i;
		this.y = j;
		this.z = k;
	}
	
	public int getDist(Object other) {
		if(getClass().equals(other.getClass())) {
			truple otherTruple = (truple) other;
			return Math.abs(x-otherTruple.x) + Math.abs(y-otherTruple.y);
		}
		else {
			pair otherPair = (pair) other;
			return Math.abs(x-otherPair.x) + Math.abs(y-otherPair.y);
		}
	}
}
