
public class pair {
	int x;
	int y;
	public pair(int i , int j) {
		this.x = i;
		this.y = j;
	}
	
	public int getDist(Object other) {
		if(getClass().equals(other.getClass())) {
			pair otherPair = (pair) other;
			return Math.abs(x-otherPair.x) + Math.abs(y-otherPair.y);
		}
		else {
			truple otherTruple = (truple) other;
			return Math.abs(x-otherTruple.x) + Math.abs(y-otherTruple.y);
		}
	}
}
