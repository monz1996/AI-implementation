
public class ShortCut {
	pair start;
	pair end;
	public ShortCut(int startX , int startY , int endX , int endY) {
		start = new pair(startX,startY);
		end = new pair(endX,endY);
	}
	//appends a pad to the shortCut
	public int append(ShortCut other) {
		int cost =0;
		if(this.end.getDist(other.start) < this.end.getDist(other.end)) {
			cost = this.end.getDist(other.start);
			this.end = new pair(other.end.x , other.end.y);
			
		}
		else if(this.end.getDist(other.start) > this.end.getDist(other.end)) {
			cost = this.end.getDist(other.end);
			this.end = new pair(other.start.x , other.start.y);
		}
		return cost;
	}
}
