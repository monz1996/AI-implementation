import java.util.Arrays;

public class State {
	//Overrided method
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		State other = (State) obj;
		return Arrays.equals(stats, other.stats);
	}
	
	
	int id; //used in overriding the methods
	int x; //Neo's x position
	int y; //Neo's y position
	int carried; //The number of hostages Neo is carring
	int health; //Neo's health from 0 to 5
	int killedHost; //The number of hostage killed either by Neo after they turned into agents or while attempting to rescue them
	int savedHost; //The number of hostages that made it to the telephone booth alive
	int killedAgents; //The amount of agents and the hostages that turned into agents killed 
	int pillsTaken; //The number of pills Neo has taken, however it is also used to generate a new state when needed
	int specialAgents; //The number of hostages that have turned into agents in the grid
	public int[] stats = new int[9]; //An array containing all the values
	
	
	//Initialize the State
	public State(int neoX , int neoY) {
		stats[0]=this.x = neoX;
		stats[1]=this.y = neoY;
		stats[2]=this.carried = 0;
		stats[3]=this.health = 5; //As Neo can only lose 20 HP
		stats[4]=this.killedHost =0;
		stats[5]=this.savedHost =0;
		stats[6]=this.killedAgents = 0;
		stats[7]=this.pillsTaken = 0;
		stats[8]=this.specialAgents = 0;
		for(int x: this.stats) {
			id = (id + (324723947 + x)) % 9;
		}
		
	}
	
	//Overrided methods
	public String toString() {
		String all = "";
		for(int x : this.stats)
		all += x + " ";
		
		
		return all;
	}
	
	
	public boolean equals(State other) {
		for(int i = 0 ; i<9 ; i++) {
			if(this.stats[i] != other.stats[i])
				return false;
		}
		
		return true;
		
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(stats);
		return result;
	}
}
