
public class Node {
	State state; //The state of the node
	Node parent; //The parent of the node
	String operator; //The operator that generated the node
	int depth; //The depth of the node
	int pathCost; //The path cost of the node
	int heuristicValue; //The heuristic value of the node
	
	//Initializes the Node
	public Node(State initialState){
		this.state = new State(initialState.x , initialState.y);
		this.state.carried = initialState.carried;
		this.state.health = initialState.health; 
		this.state.killedHost =initialState.killedHost;
		this.state.savedHost =initialState.savedHost;
		this.state.killedAgents = initialState.killedAgents;
		this.state.pillsTaken = initialState.pillsTaken;
		this.state.specialAgents = initialState.specialAgents;
		for(int i = 0;i<9;i++)this.state.stats[i] = initialState.stats[i];
		this.parent = null;
		this.operator = null;
		this.depth = 0;
		this.pathCost = 0;
		this.heuristicValue = 0;
	}
}
