import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

abstract class SearchProblem {
	State initialState;
	
	
	
	//Calculates the path cost of the node
	public void assignPathCost(Node node , int noHostages) {
			//this function calculates how much health the hostages and Neo are going to lose
		
			int cost = (noHostages)*2;
			
			if(node.operator.equals("kill")){
				cost += 20;
			}
			if(node.operator.equals("drop")){
				cost -= (node.state.carried)*2;
			}
			if(node.operator.equals("takePill")) {
				cost = 0;
			}
			if(node.parent != null) {
				cost += node.parent.pathCost;
			}
			
			node.pathCost = cost;
		}
	
	//Calculates the Hueristic value of the node
	
	public void assignHeuristic(Node node ,ArrayList<truple> hostages , ArrayList<Integer> carriedhostages , pair telLocation , HashMap<String,pair> padLocation , HashMap<String,pair> padDestination , int pills) {
		//we want to calculate how much health will be lost until we reach the goal state
		//first we will calculate the minimum distance between Neo and each hostage
		//then we will calculate the minimum distance between each hostage and the telephone
		//accordingly we can calculate how much health they are going to lost
		//afterwards we will calculate the minimum distance between Neo and the telephone to calculate how much health the carried hostages will lose
		//finally we add the ciel of (the number of special agents devided by four) and multiply it by 20, because Neo can kill a maximum of 4 agents with one hit
		
		//the heuristic value
		int heuristic = 0;
		
		//Neo's position and health
		pair neoLocation = new pair(node.state.x , node.state.y);
		int health = node.state.health;
		
		//The number of special agents
		int specialAgents = node.state.specialAgents;
		
		
		//In case Neo can't kill the special agents, return infinty
		if(4*(health + pills) < specialAgents) {
			node.heuristicValue = Integer.MAX_VALUE;
			return;
		}
		
		//calculates the minimum trip distance for Neo to go to the hostages, pick them up and go back to the telephone 
		for(truple hostage : hostages) {
			int minDistance = neoLocation.getDist(hostage);
			int minTelephoneDist = hostage.getDist(telLocation);
			
			for(Map.Entry pad : padLocation.entrySet()) {
				int distanceUsingPad = Integer.MAX_VALUE;
				int telDistanceUsingPad = Integer.MAX_VALUE;
						
				pair firstPad = (pair) pad.getValue();
				pair secondPad = padDestination.get(pad.getKey());
				
				//we add 1 because of the time taken to fly from one pad to the other
				if(firstPad.getDist(neoLocation) < secondPad.getDist(neoLocation)) {
					distanceUsingPad = neoLocation.getDist(firstPad) + secondPad.getDist(hostage) +1;
				}
				else if(firstPad.getDist(neoLocation) > secondPad.getDist(neoLocation)) {
					distanceUsingPad = neoLocation.getDist(secondPad) + firstPad.getDist(hostage) +1;
				}
				
				if( hostage.getDist(firstPad) < hostage.getDist(secondPad)) {
					telDistanceUsingPad = hostage.getDist(firstPad) + secondPad.getDist(telLocation) +1;
				}
				else if(hostage.getDist(firstPad) > hostage.getDist(secondPad)) {
					//we add 1 because of the time taken to fly from one pad to the other
					telDistanceUsingPad = hostage.getDist(secondPad) + firstPad.getDist(telLocation) +1;
				}
				
				minDistance = Math.min(minDistance, distanceUsingPad);
				minTelephoneDist = Math.min(minTelephoneDist, telDistanceUsingPad);
			}
			//we add 1 because of the time take for Neo to carry the hostage
			heuristic += Math.min(100 - hostage.z, (minDistance + minTelephoneDist + 1)*2);
		}
		
		int minTelephoneDist = neoLocation.getDist(telLocation);
			
		for(Map.Entry pad : padLocation.entrySet()) {
			int telDistanceUsingPad = Integer.MAX_VALUE;
				
			pair firstPad = (pair) pad.getValue();
			pair secondPad = padDestination.get(pad.getKey());
			
			//we add 1 because of the time taken to fly from one pad to the other
			if( neoLocation.getDist(firstPad) < neoLocation.getDist(secondPad)) {
				telDistanceUsingPad = neoLocation.getDist(firstPad) + secondPad.getDist(telLocation) +1;
			}
			else if(neoLocation.getDist(firstPad) > neoLocation.getDist(secondPad)) {
				telDistanceUsingPad = neoLocation.getDist(secondPad) + firstPad.getDist(telLocation) +1;
			}
			minTelephoneDist = Math.min(minTelephoneDist, telDistanceUsingPad);
		}
		for(int carriedHostageDamage : carriedhostages) {
			heuristic += Math.min(100 - carriedHostageDamage, 2*minTelephoneDist);
		}
		
		heuristic += Math.ceil((float)node.state.specialAgents/4)*20;
		
		node.heuristicValue = heuristic;
	}
	public void assignHeuristic2() {
		
	}

	//Checks if the node is a goal node
	public boolean goalTest(Node node , int hostages , String[][] grid) {
		return (node.state.savedHost + node.state.killedHost) == hostages && grid[node.state.x][node.state.y].contains("Telephone");
	}
	
	//These methods generates a new Node when using each operator, however the changes in the state are done in the method called updateGrid in the matrix class 
	public Node up(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "up";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node down(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "down";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node left(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "left";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node right(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "right";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node fly(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "fly";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node carry(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "carry";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node drop(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "drop";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node takePill(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "takePill";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	public Node kill(Node node) {
		Node newNode = new Node(node.state);
		newNode.parent = node;
		newNode.operator = "kill";
		newNode.depth = 1+ node.depth;
		return newNode;
	}
	
	
}
